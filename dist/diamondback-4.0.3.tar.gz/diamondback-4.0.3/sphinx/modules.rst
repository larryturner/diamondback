diamondback
===========

.. toctree::
   :maxdepth: 4
   
   diamondback
   noxfile
   setup
