noxfile module
==============

.. automodule:: noxfile
   :members:
   :noindex:
   :undoc-members:
   :show-inheritance:
