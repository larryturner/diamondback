"""" **Description**

        Time zone interface.

    **Example**

        ::

            from dateutil import tz
            from diamondback import ITimeZone
            import datetime


            class Test( ITimeZone ) :

                def __init__( self ) -> None :

                    super( ).__init__( )

                    self.timezone = datetime.timezone.utc

            test = Test( )

            test.timezone = tz.gettz( 'US/Eastern' )

    **License**

        `BSD-3C.  <https://github.com/larryturner/diamondback/blob/master/license>`_

        © 2018 - 2021 Larry Turner, Schneider Electric Industries SAS. All rights reserved.

    **Author**

        Larry Turner, Schneider Electric, Analytics & AI, 2018-07-12.

    **Definition**

"""

from diamondback.interfaces.IEqual import IEqual
import datetime


class ITimeZone( IEqual ) :

    """ Time zone interface.
    """

    @property
    def timezone( self ) :

        """ timezone : datetime.timezone.
        """

        return self._timezone

    @timezone.setter
    def timezone( self, timezone : datetime.timezone ) :

        if ( not timezone ) :

            raise ValueError( f'TimeZone = {timezone}' )

        self._timezone = timezone

    def __eq__( self, other : any ) -> bool :

        """ Equal.

            Arguments :

                other : any.

            Returns :

                equal : bool.
        """

        return ( ( super( ).__eq__( other ) ) and ( self.timezone == other.timezone ) )

    def __init__( self ) -> None :

        """ Initialize.
        """

        super( ).__init__( )

        self._timezone = datetime.timezone.utc
